import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Collapsible Sidebar')),
        body: CollapsibleSidebar(),
      ),
    );
  }
}

class CollapsibleSidebar extends StatefulWidget {
  @override
  _CollapsibleSidebarState createState() => _CollapsibleSidebarState();
}

class _CollapsibleSidebarState extends State<CollapsibleSidebar> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        AnimatedContainer(
          duration: Duration(milliseconds: 300),
          width: _isExpanded ? 200 : 70,
          color: Colors.blue,
          child: Column(
            children: [
              IconButton(
                icon: Icon(
                  _isExpanded ? Icons.arrow_back : Icons.arrow_forward,
                  color: Colors.white,
                ),
                onPressed: () {
                  setState(() {
                    _isExpanded = !_isExpanded;
                  });
                },
              ),
              if (_isExpanded)
                ...[
                  ListTile(
                    leading: Icon(Icons.home, color: Colors.white),
                    title: Text('Home', style: TextStyle(color: Colors.white)),
                  ),
                  ListTile(
                    leading: Icon(Icons.person, color: Colors.white),
                    title: Text('Profile', style: TextStyle(color: Colors.white)),
                  ),
                  // Add more list items here
                ]
              else
                ...[
                  Icon(Icons.home, color: Colors.white),
                  SizedBox(height: 10),
                  Icon(Icons.person, color: Colors.white),
                  // Add more icons here
                ],
            ],
          ),
        ),
        Expanded(
          child: Center(
            child: Text('Main Content Area'),
          ),
        ),
      ],
    );
  }
}